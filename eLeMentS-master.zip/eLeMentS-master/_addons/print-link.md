---
name: print-link
menus:
  - title: "Print"
    href: "javascript:window.print()"
    icon: print
---

# Print link

This add-on adds a "Print" link to the menu bar.