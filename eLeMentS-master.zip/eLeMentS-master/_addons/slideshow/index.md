---
name: slideshow
links:
  - href: slides.css
  - href: slides-customization.css
scripts:
  - src: slides.js
    async: True
menus:
  - title: Start slideshow
    href: "javascript:SlideShow.play()"
    icon: tv
---

## Slideshow

This addon adds a slide presentation widget to any page.
