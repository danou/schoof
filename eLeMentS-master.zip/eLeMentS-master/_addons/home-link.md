---
name: home-link
menus:
  - title: "Home"
    href: "/"
    icon: home
---

# Home link

This add-on adds a "Home" link to the menu bar.
