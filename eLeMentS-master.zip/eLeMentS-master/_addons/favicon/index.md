---
name: favicon
links:
  - href: favicon.png
    rel: shortcut icon
    type: image/png
---

# Favicon

This plugin adds a favicon.
