---
name: mathjax
scripts:
  - src: mathjax.conf.js
  - src: //cdn.mathjax.org/mathjax/latest/MathJax.js
---

# MathJax

This plugin adds support for [MathJax](https://www.mathjax.org/) to
pages.
